#ifndef MY_FILE
#define MY_FILE

#include <stdio.h>
extern int encode();
extern int decode();
extern FILE *readingf;
extern FILE *writingf;
extern int charinput;
#endif